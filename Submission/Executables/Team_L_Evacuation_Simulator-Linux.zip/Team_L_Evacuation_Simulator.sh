#!/bin/sh
java -XX:+OptimizeStringConcat -jar Team_L_Evacuation_Simulator.jar
        