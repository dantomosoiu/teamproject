#!/bin/sh
java -XX:+OptimizeStringConcat -jar Team L Evacuation Simulator.jar
        