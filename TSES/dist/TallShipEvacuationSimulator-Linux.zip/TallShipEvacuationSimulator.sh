#!/bin/sh
java -XX:+OptimizeStringConcat -jar TallShipEvacuationSimulator.jar
        